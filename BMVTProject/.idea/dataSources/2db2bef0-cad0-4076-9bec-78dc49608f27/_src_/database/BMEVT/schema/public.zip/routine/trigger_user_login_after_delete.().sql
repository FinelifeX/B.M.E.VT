create function trigger_user_login_after_delete() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  DELETE FROM user_login WHERE user_login.user_id = user_profile.id;
END ;
$$;
