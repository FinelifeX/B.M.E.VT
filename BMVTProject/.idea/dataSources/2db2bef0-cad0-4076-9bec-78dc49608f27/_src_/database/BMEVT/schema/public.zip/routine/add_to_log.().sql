create function add_to_log() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  operation varchar(30);
  data_added varchar(100);
  logged varchar(254);
BEGIN
  IF    TG_OP = 'INSERT' THEN
    data_added = NEW.username;
    operation := 'Added new user ';
    logged := operation || data_added;
    INSERT INTO logs("text",added) values (logged,NOW());
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    data_added = NEW.username;
    operation := 'Updated user ';
    logged := operation || data_added;
    INSERT INTO logs("text",added) values (logged,NOW());
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    data_added = OLD.username;
    operation := 'Removed user ';
    logged := operation || data_added;
    INSERT INTO logs("text",added) values (logged,NOW());
    RETURN OLD;
  END IF;
END;
$$;
