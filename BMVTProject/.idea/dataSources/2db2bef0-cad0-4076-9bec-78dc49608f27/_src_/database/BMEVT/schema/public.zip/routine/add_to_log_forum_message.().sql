create function add_to_log_forum_message() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  operation varchar(30);
  data_added varchar(100);
  logged varchar(254);
BEGIN
  IF    TG_OP = 'INSERT' THEN
    data_added = NEW.topic;
    operation := 'Added new message ';
    logged := operation || data_added;
    INSERT INTO logs("text",added) values (logged,NOW());
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    data_added = OLD.topic;
    operation := 'Removed message ';
    logged := operation || data_added;
    INSERT INTO logs("text",added) values (logged,NOW());
    RETURN OLD;
  END IF;
END;
$$;
