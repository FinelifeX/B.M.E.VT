CREATE VIEW number_of_course_contributors AS SELECT max(user_count.count) AS max
   FROM ( SELECT count(learning.user_id) AS count
           FROM learning
          WHERE (learning.course_id = 1)) user_count;
