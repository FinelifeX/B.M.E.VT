CREATE VIEW number_of_course_contributors AS SELECT user_count.count
   FROM ( SELECT count(learning.user_id) AS count
           FROM learning
          WHERE (learning.course_id = 1)) user_count;
