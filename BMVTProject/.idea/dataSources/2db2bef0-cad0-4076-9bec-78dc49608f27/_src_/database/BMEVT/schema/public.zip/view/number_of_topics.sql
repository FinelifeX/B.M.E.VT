CREATE VIEW number_of_topics AS SELECT count(forum_message.topic) AS count
   FROM forum_message
  WHERE (forum_message.user_id = 1);
