CREATE VIEW number_of_levels_for_each_course AS SELECT course.id,
    count(level.id) AS count
   FROM (course
     LEFT JOIN level ON ((course.lvl_id = level.id)))
  GROUP BY course.id;
