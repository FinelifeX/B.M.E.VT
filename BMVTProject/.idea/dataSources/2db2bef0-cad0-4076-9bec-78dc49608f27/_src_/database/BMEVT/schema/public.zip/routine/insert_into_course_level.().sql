create function insert_into_course_level() returns void
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO course_level(course_id, course_lang, lvl_id, lvl_title, lvl_content)
  SELECT course.id, course.lang, course.lvl_id, level.title, level.content
  FROM course JOIN level ON course.lvl_id = level.id; END;
$$;
